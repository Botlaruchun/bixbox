/**
 * 
 * Example : 
 * export const proxyList = [
    "http://tsjc0u7c:tSjC0u7c@103.187.4.134:48151",
    "http://root:rZeE9x0a@103.74.102.107:62972",
    "http://2GgJdGSax:1rtqZ28MY@87.120.216.140:63882",
  ];
 */

export const proxyList = [
  "http://phamthevung1806:BcrJB3QrjS@94.131.86.50:50100",
  "http://phamthevung1806:BcrJB3QrjS@193.169.218.246:50100",
  "http://phamthevung1806:BcrJB3QrjS@95.164.151.170:50100",
];
