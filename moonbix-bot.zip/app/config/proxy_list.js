/**
 * 
 * Example : 
 * export const proxyList = [
    "http://tsjc0u7c:tSjC0u7c@103.187.4.134:48151",
    "http://root:rZeE9x0a@103.74.102.107:62972",
    "http://2GgJdGSax:1rtqZ28MY@87.120.216.140:63882",
  ];
 */

export const proxyList = [
  "http://tsjc0u7c:tSjC0u7c@103.187.4.134:48151",
  "http://root:rZeE9x0a@103.74.102.107:62972",
  "http://2GgJdGSax:1rtqZ28MY@87.120.216.140:63882",
];
