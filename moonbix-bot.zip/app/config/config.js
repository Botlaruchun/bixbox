export class Config {
  static TELEGRAM_APP_ID = undefined; // YOUR APP ID EX : 
  static TELEGRAM_APP_HASH = undefined; // YOUR APP HASH EX: ""
  static RUNMODE = 2; // 1 FOR 1 BY 1 RUN & 2 FOR MASS RUN
}
